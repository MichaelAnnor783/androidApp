import 'package:flutter/material.dart';
import 'main.dart';


class LoginForm extends StatefulWidget {
  const LoginForm({super.key});

  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  String _errorMessage = '';

  void _validateLogin() {
    setState(() {
      _errorMessage = '';
      String email = _emailController.text;
      String password = _passwordController.text;

      if (!email.contains('@')) {
        _errorMessage = 'Please enter a valid email.';
      } else if (password.length < 6) {
        _errorMessage = 'Password must be at least 6 characters.';
      } else {
        // Proceed with login
        _errorMessage = 'Login successful!';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          controller: _emailController,
          decoration: InputDecoration(labelText: 'Email'),
        ),
        TextField(
          controller: _passwordController,
          decoration: InputDecoration(labelText: 'Password'),
          obscureText: true,
        ),
        ElevatedButton(
          onPressed: _validateLogin,
          child: Text('Login'),
        ),
        if (_errorMessage.isNotEmpty)
          Text(
            _errorMessage,
            style: TextStyle(color: Colors.red),
          ),
      ],
    );
  }
}